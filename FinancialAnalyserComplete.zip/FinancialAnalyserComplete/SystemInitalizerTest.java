/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

        
/**
 *
 * @author Sarah
 */
public class SystemInitalizerTest {
    

    /**
     * Test of relativeAccountBalance method, of class SystemInitalizer.
     */
    @org.junit.jupiter.api.Test
    public void testRelativeAccountBalance() {
        //Fake data
        ArrayList<ArrayList<Object>> mockData = new ArrayList<ArrayList<Object>>();
        ArrayList<Object> set = new ArrayList<Object>();
        ArrayList<Object> set2 = new ArrayList<Object>();
        set.add("TX10001");
        set.add("ACC334455");
        set.add("ACC778899");
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        try{
        Date testDate = formatter.parse("20/10/2018 12:47:55");
        set.add(testDate);
        }catch(ParseException e){
             e.printStackTrace();
        }
        set.add((float)25.5);
        set.add("PAYMENT");
        set.add("");
        mockData.add(set);
        
        set2.add("TX10001");
        set2.add("ACC334455");
        set2.add("ACC778899");
        try{
        Date testDate = formatter.parse("20/10/2018 12:50:55");
        set2.add(testDate);
        }catch(ParseException e){
             e.printStackTrace();
        }
        set2.add((float)10);
        set2.add("REVERSAL");
        set2.add("TX10004");
        mockData.add(set2);
        
       try{
            String accID = "ACC334455";
            //Input starting date
            Date start = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse("20/10/2018 12:00:00");
            //Input end date
            Date end = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse("20/10/2018 19:00:00");
            ArrayList<Object> actual = SystemInitalizer.relativeAccountBalance(accID, mockData, start, end);
            ArrayList<Object> expected = new ArrayList<Object>();
            expected.add((float)-15.5);
            expected.add(2);
            assertEquals(expected, actual);
            }
            catch(ParseException e){
                e.printStackTrace();
            }
    }

    /**
     * Test of TransactionRecord method, of class SystemInitalizer.
     */
    @org.junit.jupiter.api.Test
    public void testAll() {
         String filepath = "FinancialRecords.csv";  
            try{
                ArrayList<ArrayList<Object>> record = SystemInitalizer.TransactionRecord(filepath);
                String accID = "ACC334455";
                //Input starting date
                Date start = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse("20/10/2018 12:00:00");
                //Input end date
                Date end = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse("21/10/2018 19:00:00");
                
                ArrayList<Object> actual = SystemInitalizer.relativeAccountBalance(accID, record, start,  end);

                ArrayList<Object> expected = new ArrayList<Object>();
                expected.add((float)-32.25);
                expected.add(4);
                assertEquals(expected, actual);
            }
            catch(ParseException e){
                e.printStackTrace();
            }
    }
    
        /**
     * Test of Reversals, of class SystemInitalizer.
     */
    @org.junit.jupiter.api.Test
    public void testJustReversals(){
        String filepath = "FinancialRecords.csv";  
            try{
                ArrayList<ArrayList<Object>> record = SystemInitalizer.TransactionRecord(filepath);
                String accID = "ACC334455";
                //Input starting date
                Date start = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse("20/10/2018 19:15:00");
                //Input end date
                Date end = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse("20/10/2018 21:00:00");
                
                ArrayList<Object> actual = SystemInitalizer.relativeAccountBalance(accID, record, start,  end);

                ArrayList<Object> expected = new ArrayList<Object>();
                expected.add((float)10.5);
                expected.add(1);
                assertEquals(expected, actual);
            }
            catch(ParseException e){
                e.printStackTrace();
            }
    }

}
