import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner; // Import the Scanner class to read text files
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Sarah
 */
public class SystemInitalizer {
   
    public static ArrayList<Object> relativeAccountBalance(String accID, ArrayList<ArrayList<Object>> list, Date start, Date end){
        ArrayList<Float> accMoney = new ArrayList<Float>();
        int numberOfTransactions = 0;
        float sum = 0;
        for(int i=0; i < list.size(); i++)
        {
           Date create = (Date)list.get(i).get(3);
           if(create.compareTo(start) > 0 && create.compareTo(end) < 0 ){
                if(list.get(i).get(1).equals(accID)){
                    float a = ((float)list.get(i).get(4));
                    if(list.get(i).get(5).equals("PAYMENT")){
                         a *= -1;
                    }
                    else{
                        a *= +1;
                    }
                    numberOfTransactions += 1; 
                    accMoney.add(a);
                }               
            }
        }

        for(int i = 0; i < accMoney.size(); i++){ 
            sum = sum + accMoney.get(i);
        }
        ArrayList<Object> result = new ArrayList<Object>();
        result.add(sum);
        result.add(numberOfTransactions);       
        return result;
    }
    
    public static ArrayList<ArrayList<Object>> TransactionRecord (String filepath) { 
        ArrayList<ArrayList<Object>> record = new ArrayList<ArrayList<Object>>();
        try {
            File myRecords = new File(filepath);
            Scanner myReader = new Scanner(myRecords);

            //Skip first line of CSV
            myReader.nextLine();

            while (myReader.hasNextLine()) {
                Scanner line = new Scanner(myReader.nextLine());
                try{
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                    line.useDelimiter(",");
                    
                    String transactionId = line.next();
                    String fromAccountId = line.next();
                    String toAccountId = line.next();

                    Date createdAt = formatter.parse(line.next());
                    float amount = Float.parseFloat(line.next());
                    String transactionType = line.next(); 
                    String relatedTransaction = "";
                    if(line.hasNext()){
                        relatedTransaction = line.next();
                    }

                   ArrayList<Object> set = new ArrayList<Object>();
                    set.add(transactionId);
                    set.add(fromAccountId);
                    set.add(toAccountId);
                    set.add(createdAt);
                    set.add(amount);
                    set.add(transactionType);
                    set.add(relatedTransaction);
                    record.add(set);

                    line.close();
                    }  
                    catch (ParseException e) {
                        e.printStackTrace();
                        }
                    }
                myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return record;
    }

    public static void main(String[] args) {
        String filepath = "FinancialRecords.csv";
         ArrayList<ArrayList<Object>> record = TransactionRecord(filepath);
              try{
                //Account ID 
                String accID = "ACC334455";
                //Input starting date
                Date start = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse("20/10/2018 12:00:00");
                //Input end date
                Date end = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse("20/10/2018 19:00:00");
                ArrayList<Object> relative = relativeAccountBalance(accID, record, start,  end);
                System.out.println("Relative balance for the period is: " + relative.get(0));
                System.out.println("Number of transactions included is: " + relative.get(1));
            }
            catch(ParseException e){
                e.printStackTrace();
            }
        

    }

}
